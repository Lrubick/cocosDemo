"use strict";
cc._RF.push(module, '6f8a0TF2f1KHY+ujsHSxUx+', 'main');
// Script/main.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var main = /** @class */ (function (_super) {
    __extends(main, _super);
    function main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.title = null;
        _this.questionNode = [];
        _this.product = null;
        _this.kv = null;
        _this.posters = null;
        _this.copywriting = [];
        _this.shareNode = null;
        _this.toast = null;
        _this.clickAudio = null;
        _this._camera = null;
        _this._texture = null;
        _this.firstX = null;
        _this.firsty = null;
        _this.pageIndex = 1;
        return _this;
        // update (dt) {}
    }
    // onLoad () {}
    main.prototype.start = function () {
        cc.tween(this.title)
            .to(0.3, { scale: 1.2 })
            .to(0.2, { scale: 1 })
            .start();
    };
    main.prototype.touchCheck = function (eventNode) {
        eventNode.on(cc.Node.EventType.TOUCH_START, function (event) {
            var location = event.getLocation(); // 获取节点坐标
            this.firstX = location.x;
            this.firstY = location.y;
        }, this);
        eventNode.on(cc.Node.EventType.TOUCH_END, function (event) {
            var _this = this;
            var touchPoint = event.getLocation();
            var endX = this.firstX - touchPoint.x;
            var endY = this.firstY - touchPoint.y;
            if (Math.abs(endX) > Math.abs(endY)) {
                //手势向左右
                //判断向左还是向右 
                if (endX > 0) {
                    //向左函数
                    cc.log('left');
                }
                else {
                    //向右函数
                    cc.log('right');
                }
            }
            else {
                //手势向上下
                //判断手势向上还是向下
                if (endY > 0) {
                    //向下函数
                    cc.log('down');
                }
                else {
                    //向上函数
                    cc.log('up');
                    cc.tween(eventNode.parent)
                        .to(3, { y: 10000 })
                        .start();
                    this.pageIndex += 1;
                    if (this.pageIndex > 1 && this.pageIndex < 6) {
                        cc.tween(this.questionNode[this.pageIndex - 1].getChildByName("question").getChildByName("layout"))
                            // .delay(0.7)
                            .to(1, { x: -1 })
                            .start();
                    }
                    if (this.pageIndex === 2) {
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("butterfly").getComponent(cc.Animation).play();
                    }
                    if (this.pageIndex === 3) {
                        cc.tween(this.questionNode[this.pageIndex - 1].getChildByName("question").getChildByName("tanQi"))
                            .to(1.3, { scale: 1 })
                            .start();
                        cc.tween(this.questionNode[this.pageIndex - 1].getChildByName("question").getChildByName("talk"))
                            .to(1, { scale: 1 })
                            .start();
                    }
                    if (this.pageIndex === 4) {
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("threeballoon").getComponent(cc.Animation).play();
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("water planet ballon").getComponent(cc.Animation).play();
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("1balloon").getComponent(cc.Animation).play();
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("2balloon").getComponent(cc.Animation).play();
                    }
                    if (this.pageIndex === 6) {
                        cc.tween(this.product.getChildByName("star"))
                            .to(0.7, { opacity: 255 })
                            .call(function () {
                            _this.product.getChildByName("introduction").getComponent(cc.Animation).play();
                        })
                            .start();
                    }
                }
            }
        }, this);
    };
    main.prototype.questionSelect = function (event, value) {
        var _this = this;
        this.clickAudio.play();
        switch (value) {
            case "start":
                this.kv.getChildByName("bigStar").getComponent(cc.Animation).stop();
                this.kv.getChildByName("star").getComponent(cc.Animation).stop();
                this.kv.getChildByName("bigStar").active = false;
                this.kv.getChildByName("star").active = false;
                cc.tween(this.kv)
                    .to(3, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[0].getChildByName("question").getChildByName("layout"))
                    .delay(0.7)
                    .to(1, { x: -1 })
                    .start();
                break;
            case "1":
            case "2":
            case "3":
                cc.tween(this.questionNode[0].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[0].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[0].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[0].getChildByName("answer"));
                break;
            case "4":
            case "5":
            case "6":
                cc.tween(this.questionNode[1].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[1].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[1].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[1].getChildByName("answer"));
                break;
            case "7":
            case "8":
            case "9":
                cc.tween(this.questionNode[2].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[2].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[2].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[2].getChildByName("answer"));
                break;
            case "10":
            case "11":
            case "12":
                cc.tween(this.questionNode[3].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[3].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[3].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[3].getChildByName("answer"));
                break;
            case "13":
            case "14":
            case "15":
                cc.tween(this.questionNode[4].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[4].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[4].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[4].getChildByName("answer"));
                break;
            case "look":
                cc.tween(this.product)
                    .to(4, { y: 10000 })
                    .call(function () {
                    _this.initRender();
                })
                    .start();
                cc.tween(this.posters.getChildByName("cat"))
                    .repeatForever(cc.tween(this.posters.getChildByName("cat"))
                    .to(0.6, { y: 430 })
                    .to(0.6, { y: 420 })
                    .start()).start();
                cc.tween(this.posters.getChildByName("star"))
                    .to(0.8, { opacity: 255 })
                    .start();
                var rand = Math.floor(Math.random() * 4);
                cc.tween(this.posters.getChildByName("star"))
                    .to(0.8, { opacity: 255 })
                    .start();
                cc.tween(this.copywriting[rand])
                    .delay(0.8)
                    .to(0.8, { opacity: 255 })
                    .start();
                break;
            case "again":
                history.go(0);
                break;
            case "share":
                break;
            case "closeShare":
                var div_btn = document.getElementById("div_btn");
                div_btn.style.display = "block";
                var music2 = document.getElementById("audio_boxID");
                music2.style.display = "block";
                this.shareNode.active = false;
                break;
            case "tao":
                break;
        }
    };
    main.prototype.copyToClipBoard = function () {
        var _this = this;
        if (cc.sys.isNative) {
            //原生自己实现
        }
        else if (cc.sys.isBrowser) {
            var textArea = document.getElementById("clipBoard");
            if (textArea === null) {
                textArea = document.createElement("textarea");
                textArea.id = "clipBoard";
                textArea.textContent = "￥1ZQXcyb2PHb￥";
                document.body.appendChild(textArea);
            }
            textArea.select();
            try {
                var msg = document.execCommand('copy') ? 'successful' : 'unsuccessful';
                cc.log("已经复制到剪贴板");
                this.toast.getChildByName("info").getComponent(cc.Label).string = "已经复制到剪贴板";
                this.toast.active = true;
                document.body.removeChild(textArea);
            }
            catch (err) {
                this.toast.getChildByName("info").getComponent(cc.Label).string = "复制到剪贴板失败";
                this.toast.active = true;
                cc.log("复制到剪贴板失败");
            }
            this.toast.getChildByName("info").getComponent(cc.Label).scheduleOnce(function () {
                _this.toast.active = false;
            }, 2);
        }
    };
    main.prototype.initRender = function () {
        // if(cc.sys.isBrowser)
        // {
        var node = new cc.Node();
        node.parent = cc.director.getScene().getChildByName("Canvas");
        var camera = node.addComponent(cc.Camera);
        //设置相机参数
        camera.enabled = false; // 避免自动渲染
        // 截图的缩放比例
        var zoom = 1;
        var width = cc.winSize.width;
        var height = (cc.winSize.width * cc.view.getFrameSize().height) /
            cc.view.getFrameSize().width;
        var size = cc.size(width, height);
        // 截图的中心点就是摄像机节点的位置
        var origin = cc.v2(0, 0);
        camera.zoomRatio = zoom; // 设置缩放
        // 设置目标渲染纹理
        var texture = new cc.RenderTexture();
        var gl = cc.game["_renderContext"];
        texture.initWithSize(size.width, size.height, gl.STENCIL_INDEX8); // 截图矩形的尺寸
        //this.node.setPosition(origin);                  // 截图矩形的中心点
        camera.targetTexture = texture;
        // 缓存，备用
        this._camera = camera;
        this._texture = texture;
        //用于显示的sprite组件，如果要测试这个，需要添加sprite组件
        //this._sprite = this.getComponent(cc.Sprite);
        //}
        this.btn_image_knife();
    };
    /**
     * @description: 开始截图
     */
    main.prototype.btn_image_knife = function () {
        var self = this;
        this.posters.getChildByName("tao").active = false;
        this.posters.getChildByName("again").active = false;
        this.posters.getChildByName("share").active = false;
        // 执行一次 render，将所渲染的内容渲染到纹理上
        this._camera.render(undefined);
        //到这里，截图就已经完成了
        this.posters.getChildByName("tao").active = true;
        this.posters.getChildByName("again").active = true;
        this.posters.getChildByName("share").active = true;
        // 接下去，可以从 RenderTexture 中获取数据，进行深加工
        var texture = this._texture;
        var data = texture.readPixels();
        var width = texture.width;
        "";
        var height = texture.height;
        // 接下来就可以对这些数据进行操作了
        // let canvas:HTMLCanvasElement;
        var canvas = document.createElement("canvas");
        // document.body.appendChild(btn); // 没有添加到body上，不用担心内存泄漏
        var ctx = canvas.getContext("2d");
        canvas.width = width;
        canvas.height = height;
        // 1维数组转2维
        // 同时做个上下翻转
        var rowBytes = width * 4;
        for (var row = 0; row < height; row++) {
            var srow = height - 1 - row;
            var imageData = ctx.createImageData(width, 1);
            var start = srow * width * 4;
            for (var i = 0; i < rowBytes; i++) {
                imageData.data[i] = data[start + i];
            }
            ctx.putImageData(imageData, 0, row);
        }
        var dataUrl = canvas.toDataURL("image/jpeg");
        var img = document.createElement("img");
        img.src = dataUrl; //截图数据
        img.id = "capture";
        img.alt = "capture";
        img.width = width;
        img.height = height;
        img.style.position = "fixed";
        img.style.top = "50%";
        img.style.left = "50%";
        img.style.opacity = "0";
        img.style.transform = "translate(-50%,-50%)";
        // img.onclick = function fun_call() {
        //     if (self.shareLayout.active == true) {
        //         // self.node_share.active = false;
        //         self.shareLayout.active = false;
        //     }
        // };
        //创建按钮div
        var div_btn = document.createElement("div");
        div_btn.id = "div_btn";
        div_btn.style.position = "fixed";
        div_btn.style.top = "50%";
        div_btn.style.left = "0px";
        div_btn.style.width = "100%";
        div_btn.style.height = "584px";
        div_btn.appendChild(img);
        //加按钮
        var btn_again = document.createElement("div");
        btn_again.id = "btn_again";
        btn_again.style.width = "150px";
        btn_again.style.height = "60px";
        btn_again.style.position = "absolute";
        btn_again.style.bottom = "300px";
        btn_again.style.left = "23px";
        btn_again.style.right = "0px";
        // btn_again.style.margin = "auto";
        div_btn.appendChild(btn_again);
        //再次游戏
        btn_again.onclick = function func_again() {
            history.go(0);
        };
        //加按钮
        var btn_share = document.createElement("div");
        btn_share.id = "btn_share";
        btn_share.style.width = "150px";
        btn_share.style.height = "60px";
        btn_share.style.position = "absolute";
        btn_share.style.bottom = "300px";
        // btn_share.style.left = "0px";
        btn_share.style.right = "30px";
        // btn_again.style.margin = "auto";
        div_btn.appendChild(btn_share);
        //再次游戏
        btn_share.onclick = function func_again() {
            self.shareNode.active = true;
            var music = document.getElementById("audio_boxID");
            div_btn.style.display = "none";
            music.style.display = "none";
        };
        //加按钮
        var btn_tao = document.createElement("div");
        btn_tao.id = "btn_tao";
        btn_tao.style.width = "160px";
        btn_tao.style.height = "50px";
        btn_tao.style.position = "absolute";
        btn_tao.style.bottom = "370px";
        btn_tao.style.left = "0px";
        btn_tao.style.right = "0px";
        btn_tao.style.margin = "auto";
        div_btn.appendChild(btn_tao);
        //再次游戏
        btn_tao.onclick = function func_again() {
            self.copyToClipBoard();
        };
        var divGame = document.getElementById("Cocos2dGameContainer");
        divGame.appendChild(div_btn);
        // createErweima();
        //截图完成后隐藏
        // this.node_save.active = false;
        //截图完成后显示结果页
        // this.node_result.active = true;
        // this.node_result_win.active = true;
        // this.node_result.getChildByName("result_" + this.question_index).active = true;
    };
    __decorate([
        property(cc.Node)
    ], main.prototype, "title", void 0);
    __decorate([
        property([cc.Node])
    ], main.prototype, "questionNode", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "product", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "kv", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "posters", void 0);
    __decorate([
        property([cc.Node])
    ], main.prototype, "copywriting", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "shareNode", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "toast", void 0);
    __decorate([
        property(cc.AudioSource)
    ], main.prototype, "clickAudio", void 0);
    __decorate([
        property(cc.Camera)
    ], main.prototype, "_camera", void 0);
    __decorate([
        property(cc.RenderTexture)
    ], main.prototype, "_texture", void 0);
    main = __decorate([
        ccclass
    ], main);
    return main;
}(cc.Component));
exports.default = main;

cc._RF.pop();