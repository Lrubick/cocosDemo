
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/loading');
require('./assets/Script/main');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/loading.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'loading');
// Script/loading.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.text = 'hello';
        _this.planet = null;
        _this.progressBar = null;
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
        // this.label.string = this.text;
        cc.tween(this.planet)
            .by(2, { angle: 360 })
            .repeatForever()
            .start();
        var self = this;
        cc.director.preloadScene("main", function (completedCount, totalCount, item) {
            self.label.string = Math.floor(completedCount / totalCount * 100) + "%";
            self.progressBar.progress = completedCount / totalCount;
        }, function () {
            cc.log("Next scene preloaded");
            cc.director.loadScene("main");
        });
    };
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "label", void 0);
    __decorate([
        property
    ], Helloworld.prototype, "text", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "planet", void 0);
    __decorate([
        property(cc.ProgressBar)
    ], Helloworld.prototype, "progressBar", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxsb2FkaW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBZ0NDO1FBN0JHLFdBQUssR0FBYSxJQUFJLENBQUM7UUFHdkIsVUFBSSxHQUFXLE9BQU8sQ0FBQztRQUd2QixZQUFNLEdBQVksSUFBSSxDQUFDO1FBR3ZCLGlCQUFXLEdBQW1CLElBQUksQ0FBQzs7SUFvQnZDLENBQUM7SUFsQkcsMEJBQUssR0FBTDtRQUNJLGFBQWE7UUFDYixpQ0FBaUM7UUFDakMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO2FBQ2hCLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUM7YUFDckIsYUFBYSxFQUFFO2FBQ2YsS0FBSyxFQUFFLENBQUE7UUFFWixJQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLFVBQUMsY0FBc0IsRUFBRSxVQUFrQixFQUFFLElBQVk7WUFDdEYsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsVUFBVSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztZQUN4RSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsR0FBRyxjQUFjLEdBQUcsVUFBVSxDQUFDO1FBQzVELENBQUMsRUFBRTtZQUNDLEVBQUUsQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQztZQUMvQixFQUFFLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNsQyxDQUFDLENBQUMsQ0FBQztJQUVQLENBQUM7SUE1QkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzs2Q0FDSTtJQUd2QjtRQURDLFFBQVE7NENBQ2M7SUFHdkI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzs4Q0FDSztJQUd2QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDO21EQUNVO0lBWmxCLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0FnQzlCO0lBQUQsaUJBQUM7Q0FoQ0QsQUFnQ0MsQ0FoQ3VDLEVBQUUsQ0FBQyxTQUFTLEdBZ0NuRDtrQkFoQ29CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSGVsbG93b3JsZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLkxhYmVsKVxyXG4gICAgbGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHlcclxuICAgIHRleHQ6IHN0cmluZyA9ICdoZWxsbyc7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwbGFuZXQ6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Qcm9ncmVzc0JhcilcclxuICAgIHByb2dyZXNzQmFyOiBjYy5Qcm9ncmVzc0JhciA9IG51bGw7XHJcblxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgLy8gaW5pdCBsb2dpY1xyXG4gICAgICAgIC8vIHRoaXMubGFiZWwuc3RyaW5nID0gdGhpcy50ZXh0O1xyXG4gICAgICAgIGNjLnR3ZWVuKHRoaXMucGxhbmV0KVxyXG4gICAgICAgICAgICAuYnkoMiwgeyBhbmdsZTogMzYwIH0pXHJcbiAgICAgICAgICAgIC5yZXBlYXRGb3JldmVyKClcclxuICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgY29uc3Qgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IucHJlbG9hZFNjZW5lKFwibWFpblwiLCAoY29tcGxldGVkQ291bnQ6IG51bWJlciwgdG90YWxDb3VudDogbnVtYmVyLCBpdGVtOiBPYmplY3QpID0+IHtcclxuICAgICAgICAgICAgc2VsZi5sYWJlbC5zdHJpbmcgPSBNYXRoLmZsb29yKGNvbXBsZXRlZENvdW50IC8gdG90YWxDb3VudCAqIDEwMCkgKyBcIiVcIjtcclxuICAgICAgICAgICAgc2VsZi5wcm9ncmVzc0Jhci5wcm9ncmVzcyA9IGNvbXBsZXRlZENvdW50IC8gdG90YWxDb3VudDtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIk5leHQgc2NlbmUgcHJlbG9hZGVkXCIpO1xyXG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJtYWluXCIpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgIH1cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/main.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6f8a0TF2f1KHY+ujsHSxUx+', 'main');
// Script/main.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var main = /** @class */ (function (_super) {
    __extends(main, _super);
    function main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.title = null;
        _this.questionNode = [];
        _this.product = null;
        _this.kv = null;
        _this.posters = null;
        _this.copywriting = [];
        _this.shareNode = null;
        _this.toast = null;
        _this.clickAudio = null;
        _this._camera = null;
        _this._texture = null;
        _this.firstX = null;
        _this.firsty = null;
        _this.pageIndex = 1;
        return _this;
        // update (dt) {}
    }
    // onLoad () {}
    main.prototype.start = function () {
        cc.tween(this.title)
            .to(0.3, { scale: 1.2 })
            .to(0.2, { scale: 1 })
            .start();
    };
    main.prototype.touchCheck = function (eventNode) {
        eventNode.on(cc.Node.EventType.TOUCH_START, function (event) {
            var location = event.getLocation(); // 获取节点坐标
            this.firstX = location.x;
            this.firstY = location.y;
        }, this);
        eventNode.on(cc.Node.EventType.TOUCH_END, function (event) {
            var _this = this;
            var touchPoint = event.getLocation();
            var endX = this.firstX - touchPoint.x;
            var endY = this.firstY - touchPoint.y;
            if (Math.abs(endX) > Math.abs(endY)) {
                //手势向左右
                //判断向左还是向右 
                if (endX > 0) {
                    //向左函数
                    cc.log('left');
                }
                else {
                    //向右函数
                    cc.log('right');
                }
            }
            else {
                //手势向上下
                //判断手势向上还是向下
                if (endY > 0) {
                    //向下函数
                    cc.log('down');
                }
                else {
                    //向上函数
                    cc.log('up');
                    cc.tween(eventNode.parent)
                        .to(3, { y: 10000 })
                        .start();
                    this.pageIndex += 1;
                    if (this.pageIndex > 1 && this.pageIndex < 6) {
                        cc.tween(this.questionNode[this.pageIndex - 1].getChildByName("question").getChildByName("layout"))
                            // .delay(0.7)
                            .to(1, { x: -1 })
                            .start();
                    }
                    if (this.pageIndex === 2) {
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("butterfly").getComponent(cc.Animation).play();
                    }
                    if (this.pageIndex === 3) {
                        cc.tween(this.questionNode[this.pageIndex - 1].getChildByName("question").getChildByName("tanQi"))
                            .to(1.3, { scale: 1 })
                            .start();
                        cc.tween(this.questionNode[this.pageIndex - 1].getChildByName("question").getChildByName("talk"))
                            .to(1, { scale: 1 })
                            .start();
                    }
                    if (this.pageIndex === 4) {
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("threeballoon").getComponent(cc.Animation).play();
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("water planet ballon").getComponent(cc.Animation).play();
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("1balloon").getComponent(cc.Animation).play();
                        this.questionNode[this.pageIndex - 1].getChildByName("answer").getChildByName("2balloon").getComponent(cc.Animation).play();
                    }
                    if (this.pageIndex === 6) {
                        cc.tween(this.product.getChildByName("star"))
                            .to(0.7, { opacity: 255 })
                            .call(function () {
                            _this.product.getChildByName("introduction").getComponent(cc.Animation).play();
                        })
                            .start();
                    }
                }
            }
        }, this);
    };
    main.prototype.questionSelect = function (event, value) {
        var _this = this;
        this.clickAudio.play();
        switch (value) {
            case "start":
                this.kv.getChildByName("bigStar").getComponent(cc.Animation).stop();
                this.kv.getChildByName("star").getComponent(cc.Animation).stop();
                this.kv.getChildByName("bigStar").active = false;
                this.kv.getChildByName("star").active = false;
                cc.tween(this.kv)
                    .to(3, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[0].getChildByName("question").getChildByName("layout"))
                    .delay(0.7)
                    .to(1, { x: -1 })
                    .start();
                break;
            case "1":
            case "2":
            case "3":
                cc.tween(this.questionNode[0].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[0].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[0].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[0].getChildByName("answer"));
                break;
            case "4":
            case "5":
            case "6":
                cc.tween(this.questionNode[1].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[1].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[1].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[1].getChildByName("answer"));
                break;
            case "7":
            case "8":
            case "9":
                cc.tween(this.questionNode[2].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[2].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[2].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[2].getChildByName("answer"));
                break;
            case "10":
            case "11":
            case "12":
                cc.tween(this.questionNode[3].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[3].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[3].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[3].getChildByName("answer"));
                break;
            case "13":
            case "14":
            case "15":
                cc.tween(this.questionNode[4].getChildByName("question"))
                    .to(4, { y: 10000 })
                    .start();
                cc.tween(this.questionNode[4].getChildByName("answer").getChildByName("answer1"))
                    .to(1, { opacity: 255 })
                    .start();
                cc.tween(this.questionNode[4].getChildByName("answer").getChildByName("answer2"))
                    .delay(1)
                    .to(1, { opacity: 255 })
                    .start();
                this.touchCheck(this.questionNode[4].getChildByName("answer"));
                break;
            case "look":
                cc.tween(this.product)
                    .to(4, { y: 10000 })
                    .call(function () {
                    _this.initRender();
                })
                    .start();
                cc.tween(this.posters.getChildByName("cat"))
                    .repeatForever(cc.tween(this.posters.getChildByName("cat"))
                    .to(0.6, { y: 430 })
                    .to(0.6, { y: 420 })
                    .start()).start();
                cc.tween(this.posters.getChildByName("star"))
                    .to(0.8, { opacity: 255 })
                    .start();
                var rand = Math.floor(Math.random() * 4);
                cc.tween(this.posters.getChildByName("star"))
                    .to(0.8, { opacity: 255 })
                    .start();
                cc.tween(this.copywriting[rand])
                    .delay(0.8)
                    .to(0.8, { opacity: 255 })
                    .start();
                break;
            case "again":
                history.go(0);
                break;
            case "share":
                break;
            case "closeShare":
                var div_btn = document.getElementById("div_btn");
                div_btn.style.display = "block";
                var music2 = document.getElementById("audio_boxID");
                music2.style.display = "block";
                this.shareNode.active = false;
                break;
            case "tao":
                break;
        }
    };
    main.prototype.copyToClipBoard = function () {
        var _this = this;
        if (cc.sys.isNative) {
            //原生自己实现
        }
        else if (cc.sys.isBrowser) {
            var textArea = document.getElementById("clipBoard");
            if (textArea === null) {
                textArea = document.createElement("textarea");
                textArea.id = "clipBoard";
                textArea.textContent = "￥1ZQXcyb2PHb￥";
                document.body.appendChild(textArea);
            }
            textArea.select();
            try {
                var msg = document.execCommand('copy') ? 'successful' : 'unsuccessful';
                cc.log("已经复制到剪贴板");
                this.toast.getChildByName("info").getComponent(cc.Label).string = "已经复制到剪贴板";
                this.toast.active = true;
                document.body.removeChild(textArea);
            }
            catch (err) {
                this.toast.getChildByName("info").getComponent(cc.Label).string = "复制到剪贴板失败";
                this.toast.active = true;
                cc.log("复制到剪贴板失败");
            }
            this.toast.getChildByName("info").getComponent(cc.Label).scheduleOnce(function () {
                _this.toast.active = false;
            }, 2);
        }
    };
    main.prototype.initRender = function () {
        // if(cc.sys.isBrowser)
        // {
        var node = new cc.Node();
        node.parent = cc.director.getScene().getChildByName("Canvas");
        var camera = node.addComponent(cc.Camera);
        //设置相机参数
        camera.enabled = false; // 避免自动渲染
        // 截图的缩放比例
        var zoom = 1;
        var width = cc.winSize.width;
        var height = (cc.winSize.width * cc.view.getFrameSize().height) /
            cc.view.getFrameSize().width;
        var size = cc.size(width, height);
        // 截图的中心点就是摄像机节点的位置
        var origin = cc.v2(0, 0);
        camera.zoomRatio = zoom; // 设置缩放
        // 设置目标渲染纹理
        var texture = new cc.RenderTexture();
        var gl = cc.game["_renderContext"];
        texture.initWithSize(size.width, size.height, gl.STENCIL_INDEX8); // 截图矩形的尺寸
        //this.node.setPosition(origin);                  // 截图矩形的中心点
        camera.targetTexture = texture;
        // 缓存，备用
        this._camera = camera;
        this._texture = texture;
        //用于显示的sprite组件，如果要测试这个，需要添加sprite组件
        //this._sprite = this.getComponent(cc.Sprite);
        //}
        this.btn_image_knife();
    };
    /**
     * @description: 开始截图
     */
    main.prototype.btn_image_knife = function () {
        var self = this;
        this.posters.getChildByName("tao").active = false;
        this.posters.getChildByName("again").active = false;
        this.posters.getChildByName("share").active = false;
        // 执行一次 render，将所渲染的内容渲染到纹理上
        this._camera.render(undefined);
        //到这里，截图就已经完成了
        this.posters.getChildByName("tao").active = true;
        this.posters.getChildByName("again").active = true;
        this.posters.getChildByName("share").active = true;
        // 接下去，可以从 RenderTexture 中获取数据，进行深加工
        var texture = this._texture;
        var data = texture.readPixels();
        var width = texture.width;
        "";
        var height = texture.height;
        // 接下来就可以对这些数据进行操作了
        // let canvas:HTMLCanvasElement;
        var canvas = document.createElement("canvas");
        // document.body.appendChild(btn); // 没有添加到body上，不用担心内存泄漏
        var ctx = canvas.getContext("2d");
        canvas.width = width;
        canvas.height = height;
        // 1维数组转2维
        // 同时做个上下翻转
        var rowBytes = width * 4;
        for (var row = 0; row < height; row++) {
            var srow = height - 1 - row;
            var imageData = ctx.createImageData(width, 1);
            var start = srow * width * 4;
            for (var i = 0; i < rowBytes; i++) {
                imageData.data[i] = data[start + i];
            }
            ctx.putImageData(imageData, 0, row);
        }
        var dataUrl = canvas.toDataURL("image/jpeg");
        var img = document.createElement("img");
        img.src = dataUrl; //截图数据
        img.id = "capture";
        img.alt = "capture";
        img.width = width;
        img.height = height;
        img.style.position = "fixed";
        img.style.top = "50%";
        img.style.left = "50%";
        img.style.opacity = "0";
        img.style.transform = "translate(-50%,-50%)";
        // img.onclick = function fun_call() {
        //     if (self.shareLayout.active == true) {
        //         // self.node_share.active = false;
        //         self.shareLayout.active = false;
        //     }
        // };
        //创建按钮div
        var div_btn = document.createElement("div");
        div_btn.id = "div_btn";
        div_btn.style.position = "fixed";
        div_btn.style.top = "50%";
        div_btn.style.left = "0px";
        div_btn.style.width = "100%";
        div_btn.style.height = "584px";
        div_btn.appendChild(img);
        //加按钮
        var btn_again = document.createElement("div");
        btn_again.id = "btn_again";
        btn_again.style.width = "150px";
        btn_again.style.height = "60px";
        btn_again.style.position = "absolute";
        btn_again.style.bottom = "300px";
        btn_again.style.left = "23px";
        btn_again.style.right = "0px";
        // btn_again.style.margin = "auto";
        div_btn.appendChild(btn_again);
        //再次游戏
        btn_again.onclick = function func_again() {
            history.go(0);
        };
        //加按钮
        var btn_share = document.createElement("div");
        btn_share.id = "btn_share";
        btn_share.style.width = "150px";
        btn_share.style.height = "60px";
        btn_share.style.position = "absolute";
        btn_share.style.bottom = "300px";
        // btn_share.style.left = "0px";
        btn_share.style.right = "30px";
        // btn_again.style.margin = "auto";
        div_btn.appendChild(btn_share);
        //再次游戏
        btn_share.onclick = function func_again() {
            self.shareNode.active = true;
            var music = document.getElementById("audio_boxID");
            div_btn.style.display = "none";
            music.style.display = "none";
        };
        //加按钮
        var btn_tao = document.createElement("div");
        btn_tao.id = "btn_tao";
        btn_tao.style.width = "160px";
        btn_tao.style.height = "50px";
        btn_tao.style.position = "absolute";
        btn_tao.style.bottom = "370px";
        btn_tao.style.left = "0px";
        btn_tao.style.right = "0px";
        btn_tao.style.margin = "auto";
        div_btn.appendChild(btn_tao);
        //再次游戏
        btn_tao.onclick = function func_again() {
            self.copyToClipBoard();
        };
        var divGame = document.getElementById("Cocos2dGameContainer");
        divGame.appendChild(div_btn);
        // createErweima();
        //截图完成后隐藏
        // this.node_save.active = false;
        //截图完成后显示结果页
        // this.node_result.active = true;
        // this.node_result_win.active = true;
        // this.node_result.getChildByName("result_" + this.question_index).active = true;
    };
    __decorate([
        property(cc.Node)
    ], main.prototype, "title", void 0);
    __decorate([
        property([cc.Node])
    ], main.prototype, "questionNode", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "product", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "kv", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "posters", void 0);
    __decorate([
        property([cc.Node])
    ], main.prototype, "copywriting", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "shareNode", void 0);
    __decorate([
        property(cc.Node)
    ], main.prototype, "toast", void 0);
    __decorate([
        property(cc.AudioSource)
    ], main.prototype, "clickAudio", void 0);
    __decorate([
        property(cc.Camera)
    ], main.prototype, "_camera", void 0);
    __decorate([
        property(cc.RenderTexture)
    ], main.prototype, "_texture", void 0);
    main = __decorate([
        ccclass
    ], main);
    return main;
}(cc.Component));
exports.default = main;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxtYWluLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQWtDLHdCQUFZO0lBQTlDO1FBQUEscUVBMmhCQztRQXhoQkcsV0FBSyxHQUFZLElBQUksQ0FBQztRQUd0QixrQkFBWSxHQUFjLEVBQUUsQ0FBQztRQUc3QixhQUFPLEdBQVksSUFBSSxDQUFDO1FBSXhCLFFBQUUsR0FBWSxJQUFJLENBQUM7UUFJbkIsYUFBTyxHQUFZLElBQUksQ0FBQztRQUl4QixpQkFBVyxHQUFjLEVBQUUsQ0FBQztRQUk1QixlQUFTLEdBQVksSUFBSSxDQUFDO1FBRzFCLFdBQUssR0FBWSxJQUFJLENBQUM7UUFHdEIsZ0JBQVUsR0FBbUIsSUFBSSxDQUFDO1FBR2xDLGFBQU8sR0FBYyxJQUFJLENBQUM7UUFHMUIsY0FBUSxHQUFxQixJQUFJLENBQUM7UUFFbEMsWUFBTSxHQUFXLElBQUksQ0FBQztRQUN0QixZQUFNLEdBQVcsSUFBSSxDQUFDO1FBRXRCLGVBQVMsR0FBVyxDQUFDLENBQUM7O1FBZ2Z0QixpQkFBaUI7SUFDckIsQ0FBQztJQWhmRyxlQUFlO0lBRWYsb0JBQUssR0FBTDtRQUNJLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQzthQUNmLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUM7YUFDdkIsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUNyQixLQUFLLEVBQUUsQ0FBQTtJQUNoQixDQUFDO0lBR0QseUJBQVUsR0FBVixVQUFXLFNBQWtCO1FBQ3pCLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLFVBQVUsS0FBVTtZQUM1RCxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQSxTQUFTO1lBQzVDLElBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUN6QixJQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDN0IsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRVQsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxLQUFVO1lBQXBCLGlCQTJFekM7WUExRUcsSUFBSSxVQUFVLEdBQUcsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3JDLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFFdEMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ2pDLE9BQU87Z0JBQ1AsV0FBVztnQkFDWCxJQUFJLElBQUksR0FBRyxDQUFDLEVBQUU7b0JBQ1YsTUFBTTtvQkFDTixFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUNsQjtxQkFBTTtvQkFDSCxNQUFNO29CQUNOLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQ25CO2FBQ0o7aUJBQU07Z0JBQ0gsT0FBTztnQkFDUCxZQUFZO2dCQUNaLElBQUksSUFBSSxHQUFHLENBQUMsRUFBRTtvQkFDVixNQUFNO29CQUNOLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBR2xCO3FCQUFNO29CQUNILE1BQU07b0JBQ04sRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDYixFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7eUJBQ3JCLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7eUJBQ25CLEtBQUssRUFBRSxDQUFBO29CQUVaLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDO29CQUlwQixJQUFJLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxFQUFFO3dCQUMxQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUMvRixjQUFjOzZCQUNiLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQzs2QkFDaEIsS0FBSyxFQUFFLENBQUE7cUJBQ2Y7b0JBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLENBQUMsRUFBRTt3QkFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztxQkFFaEk7b0JBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLENBQUMsRUFBRTt3QkFDdEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQzs2QkFDN0YsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQzs2QkFDckIsS0FBSyxFQUFFLENBQUE7d0JBRVosRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQzs2QkFDNUYsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQzs2QkFDbkIsS0FBSyxFQUFFLENBQUE7cUJBQ2Y7b0JBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLENBQUMsRUFBRTt3QkFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDaEksSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMscUJBQXFCLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUN2SSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM1SCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3FCQUMvSDtvQkFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssQ0FBQyxFQUFFO3dCQUV0QixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzZCQUN4QyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDOzZCQUN6QixJQUFJLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDbEYsQ0FBQyxDQUFDOzZCQUNELEtBQUssRUFBRSxDQUFBO3FCQUNmO2lCQUVKO2FBQ0o7UUFDTCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDYixDQUFDO0lBR0QsNkJBQWMsR0FBZCxVQUFlLEtBQVUsRUFBRSxLQUFhO1FBQXhDLGlCQTRLQztRQTFLRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDO1FBRXZCLFFBQVEsS0FBSyxFQUFFO1lBQ1gsS0FBSyxPQUFPO2dCQUNSLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3BFLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2pFLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7Z0JBRTlDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztxQkFDWixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO3FCQUNuQixLQUFLLEVBQUUsQ0FBQTtnQkFFWixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDN0UsS0FBSyxDQUFDLEdBQUcsQ0FBQztxQkFDVixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7cUJBQ2hCLEtBQUssRUFBRSxDQUFBO2dCQUVaLE1BQU07WUFDVixLQUFLLEdBQUcsQ0FBQztZQUNULEtBQUssR0FBRyxDQUFDO1lBQ1QsS0FBSyxHQUFHO2dCQUNKLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQ3BELEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7cUJBQ25CLEtBQUssRUFBRSxDQUFBO2dCQUVaLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM1RSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDNUUsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDUixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBRS9ELE1BQU07WUFDVixLQUFLLEdBQUcsQ0FBQztZQUNULEtBQUssR0FBRyxDQUFDO1lBQ1QsS0FBSyxHQUFHO2dCQUNKLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQ3BELEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7cUJBQ25CLEtBQUssRUFBRSxDQUFBO2dCQUVaLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM1RSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDNUUsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDUixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBRS9ELE1BQU07WUFFVixLQUFLLEdBQUcsQ0FBQztZQUNULEtBQUssR0FBRyxDQUFDO1lBQ1QsS0FBSyxHQUFHO2dCQUNKLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQ3BELEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7cUJBQ25CLEtBQUssRUFBRSxDQUFBO2dCQUVaLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM1RSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDNUUsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDUixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBRS9ELE1BQU07WUFFVixLQUFLLElBQUksQ0FBQztZQUNWLEtBQUssSUFBSSxDQUFDO1lBQ1YsS0FBSyxJQUFJO2dCQUNMLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQ3BELEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7cUJBQ25CLEtBQUssRUFBRSxDQUFBO2dCQUVaLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM1RSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDNUUsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDUixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBRS9ELE1BQU07WUFFVixLQUFLLElBQUksQ0FBQztZQUNWLEtBQUssSUFBSSxDQUFDO1lBQ1YsS0FBSyxJQUFJO2dCQUNMLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQ3BELEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7cUJBQ25CLEtBQUssRUFBRSxDQUFBO2dCQUdaLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM1RSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDNUUsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDUixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN2QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBRS9ELE1BQU07WUFDVixLQUFLLE1BQU07Z0JBQ1AsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO3FCQUNqQixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO3FCQUNuQixJQUFJLENBQUM7b0JBQ0YsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUN0QixDQUFDLENBQUM7cUJBQ0QsS0FBSyxFQUFFLENBQUE7Z0JBRVosRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdkMsYUFBYSxDQUNWLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3ZDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7cUJBQ25CLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7cUJBQ25CLEtBQUssRUFBRSxDQUNmLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBRWQsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDeEMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQztxQkFDekIsS0FBSyxFQUFFLENBQUE7Z0JBRVosSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBRXpDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7cUJBQ3hDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUM7cUJBQ3pCLEtBQUssRUFBRSxDQUFBO2dCQUVaLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDM0IsS0FBSyxDQUFDLEdBQUcsQ0FBQztxQkFDVixFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUN6QixLQUFLLEVBQUUsQ0FBQTtnQkFFWixNQUFNO1lBQ1YsS0FBSyxPQUFPO2dCQUNSLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssT0FBTztnQkFFUixNQUFNO1lBQ1YsS0FBSyxZQUFZO2dCQUNiLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUE7Z0JBQ2hELE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztnQkFDaEMsSUFBSSxNQUFNLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQTtnQkFDbkQsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2dCQUUvQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7Z0JBRTlCLE1BQU07WUFDVixLQUFLLEtBQUs7Z0JBRU4sTUFBTTtTQUViO0lBQ0wsQ0FBQztJQUdPLDhCQUFlLEdBQXZCO1FBQUEsaUJBNkJDO1FBNUJHLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUU7WUFDakIsUUFBUTtTQUNYO2FBQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRTtZQUN6QixJQUFJLFFBQVEsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3BELElBQUksUUFBUSxLQUFLLElBQUksRUFBRTtnQkFDbkIsUUFBUSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQzlDLFFBQVEsQ0FBQyxFQUFFLEdBQUcsV0FBVyxDQUFDO2dCQUMxQixRQUFRLENBQUMsV0FBVyxHQUFHLGVBQWUsQ0FBQztnQkFDdkMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDdkM7WUFDRCxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEIsSUFBSTtnQkFDQSxJQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztnQkFDekUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO2dCQUM3RSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUE7Z0JBQ3hCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3ZDO1lBQUMsT0FBTyxHQUFHLEVBQUU7Z0JBQ1YsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO2dCQUM3RSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUE7Z0JBQ3hCLEVBQUUsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDdEI7WUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQztnQkFDbEUsS0FBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQzlCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUdUO0lBQ0wsQ0FBQztJQUdPLHlCQUFVLEdBQWxCO1FBQ0ksdUJBQXVCO1FBQ3ZCLElBQUk7UUFDSixJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzlELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFDLFFBQVE7UUFFUixNQUFNLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLFNBQVM7UUFDakMsVUFBVTtRQUNWLElBQUksSUFBSSxHQUFHLENBQUMsQ0FBQztRQUNiLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQzdCLElBQUksTUFBTSxHQUNOLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxNQUFNLENBQUM7WUFDbEQsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDakMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDbEMsbUJBQW1CO1FBQ25CLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXpCLE1BQU0sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUMsT0FBTztRQUVoQyxXQUFXO1FBQ1gsSUFBSSxPQUFPLEdBQUcsSUFBSSxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRW5DLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFVBQVU7UUFDNUUsNkRBQTZEO1FBQzdELE1BQU0sQ0FBQyxhQUFhLEdBQUcsT0FBTyxDQUFDO1FBRS9CLFFBQVE7UUFDUixJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztRQUN0QixJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQztRQUV4QixvQ0FBb0M7UUFDcEMsOENBQThDO1FBQzlDLEdBQUc7UUFDSCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUlEOztPQUVHO0lBQ0ssOEJBQWUsR0FBdkI7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFFaEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNsRCxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3BELElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFFcEQsNEJBQTRCO1FBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9CLGNBQWM7UUFHZCxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2pELElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDbkQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUduRCxvQ0FBb0M7UUFDcEMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUM1QixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUM7UUFFaEMsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUFDLEVBQUUsQ0FBQTtRQUM3QixJQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1FBRTVCLG1CQUFtQjtRQUNuQixnQ0FBZ0M7UUFDaEMsSUFBSSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM5Qyx5REFBeUQ7UUFFekQsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsQyxNQUFNLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNyQixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUV2QixVQUFVO1FBQ1YsV0FBVztRQUNYLElBQUksUUFBUSxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDekIsS0FBSyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLE1BQU0sRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUNuQyxJQUFJLElBQUksR0FBRyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztZQUM1QixJQUFJLFNBQVMsR0FBRyxHQUFHLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM5QyxJQUFJLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztZQUM3QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUMvQixTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDdkM7WUFFRCxHQUFHLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDdkM7UUFDRCxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksR0FBRyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDeEMsR0FBRyxDQUFDLEdBQUcsR0FBRyxPQUFPLENBQUMsQ0FBQyxNQUFNO1FBQ3pCLEdBQUcsQ0FBQyxFQUFFLEdBQUcsU0FBUyxDQUFDO1FBQ25CLEdBQUcsQ0FBQyxHQUFHLEdBQUcsU0FBUyxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2xCLEdBQUcsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQztRQUM3QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7UUFDdEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztRQUN4QixHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxzQkFBc0IsQ0FBQztRQUM3QyxzQ0FBc0M7UUFDdEMsNkNBQTZDO1FBQzdDLDZDQUE2QztRQUM3QywyQ0FBMkM7UUFDM0MsUUFBUTtRQUNSLEtBQUs7UUFHTCxTQUFTO1FBQ1QsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM1QyxPQUFPLENBQUMsRUFBRSxHQUFHLFNBQVMsQ0FBQztRQUN2QixPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7UUFDakMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO1FBQzFCLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7UUFDN0IsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO1FBRS9CLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFekIsS0FBSztRQUNMLElBQUksU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUMsU0FBUyxDQUFDLEVBQUUsR0FBRyxXQUFXLENBQUM7UUFDM0IsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDO1FBQ2hDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNoQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUM7UUFDdEMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO1FBQ2pDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztRQUM5QixTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDOUIsbUNBQW1DO1FBRW5DLE9BQU8sQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0IsTUFBTTtRQUNOLFNBQVMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxVQUFVO1lBQ25DLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEIsQ0FBQyxDQUFDO1FBRUYsS0FBSztRQUNMLElBQUksU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUMsU0FBUyxDQUFDLEVBQUUsR0FBRyxXQUFXLENBQUM7UUFDM0IsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDO1FBQ2hDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNoQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUM7UUFDdEMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO1FBQ2pDLGdDQUFnQztRQUNoQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7UUFDL0IsbUNBQW1DO1FBRW5DLE9BQU8sQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0IsTUFBTTtRQUNOLFNBQVMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxVQUFVO1lBQ25DLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUM3QixJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFBO1lBQ2xELE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztZQUMvQixLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7UUFDakMsQ0FBQyxDQUFDO1FBSUYsS0FBSztRQUNMLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUMsT0FBTyxDQUFDLEVBQUUsR0FBRyxTQUFTLENBQUM7UUFDdkIsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDO1FBQzlCLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUM5QixPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUM7UUFDcEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO1FBQy9CLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDNUIsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1FBRTlCLE9BQU8sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDN0IsTUFBTTtRQUNOLE9BQU8sQ0FBQyxPQUFPLEdBQUcsU0FBUyxVQUFVO1lBQ2pDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUMzQixDQUFDLENBQUM7UUFLRixJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDOUQsT0FBTyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3QixtQkFBbUI7UUFFbkIsU0FBUztRQUNULGlDQUFpQztRQUNqQyxZQUFZO1FBQ1osa0NBQWtDO1FBQ2xDLHNDQUFzQztRQUN0QyxrRkFBa0Y7SUFDdEYsQ0FBQztJQXJoQkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt1Q0FDSTtJQUd0QjtRQURDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQzs4Q0FDUztJQUc3QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3lDQUNNO0lBSXhCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7b0NBQ0M7SUFJbkI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt5Q0FDTTtJQUl4QjtRQURDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQzs2Q0FDUTtJQUk1QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzJDQUNRO0lBRzFCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7dUNBQ0k7SUFHdEI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQzs0Q0FDUztJQUdsQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO3lDQUNNO0lBRzFCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUM7MENBQ087SUFyQ2pCLElBQUk7UUFEeEIsT0FBTztPQUNhLElBQUksQ0EyaEJ4QjtJQUFELFdBQUM7Q0EzaEJELEFBMmhCQyxDQTNoQmlDLEVBQUUsQ0FBQyxTQUFTLEdBMmhCN0M7a0JBM2hCb0IsSUFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBtYWluIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHRpdGxlOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoW2NjLk5vZGVdKVxyXG4gICAgcXVlc3Rpb25Ob2RlOiBjYy5Ob2RlW10gPSBbXTtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb2R1Y3Q6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIGt2OiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwb3N0ZXJzOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcblxyXG4gICAgQHByb3BlcnR5KFtjYy5Ob2RlXSlcclxuICAgIGNvcHl3cml0aW5nOiBjYy5Ob2RlW10gPSBbXTtcclxuXHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBzaGFyZU5vZGU6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgdG9hc3Q6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5BdWRpb1NvdXJjZSlcclxuICAgIGNsaWNrQXVkaW86IGNjLkF1ZGlvU291cmNlID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuQ2FtZXJhKVxyXG4gICAgX2NhbWVyYTogY2MuQ2FtZXJhID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuUmVuZGVyVGV4dHVyZSlcclxuICAgIF90ZXh0dXJlOiBjYy5SZW5kZXJUZXh0dXJlID0gbnVsbDtcclxuXHJcbiAgICBmaXJzdFg6IG51bWJlciA9IG51bGw7XHJcbiAgICBmaXJzdHk6IG51bWJlciA9IG51bGw7XHJcblxyXG4gICAgcGFnZUluZGV4OiBudW1iZXIgPSAxO1xyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgY2MudHdlZW4odGhpcy50aXRsZSlcclxuICAgICAgICAgICAgLnRvKDAuMywgeyBzY2FsZTogMS4yIH0pXHJcbiAgICAgICAgICAgIC50bygwLjIsIHsgc2NhbGU6IDEgfSlcclxuICAgICAgICAgICAgLnN0YXJ0KClcclxuICAgIH1cclxuXHJcblxyXG4gICAgdG91Y2hDaGVjayhldmVudE5vZGU6IGNjLk5vZGUpIHtcclxuICAgICAgICBldmVudE5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIGZ1bmN0aW9uIChldmVudDogYW55KSB7XHJcbiAgICAgICAgICAgIGxldCBsb2NhdGlvbiA9IGV2ZW50LmdldExvY2F0aW9uKCk7Ly8g6I635Y+W6IqC54K55Z2Q5qCHXHJcbiAgICAgICAgICAgIHRoaXMuZmlyc3RYID0gbG9jYXRpb24ueDtcclxuICAgICAgICAgICAgdGhpcy5maXJzdFkgPSBsb2NhdGlvbi55O1xyXG4gICAgICAgIH0sIHRoaXMpO1xyXG5cclxuICAgICAgICBldmVudE5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCBmdW5jdGlvbiAoZXZlbnQ6IGFueSkge1xyXG4gICAgICAgICAgICBsZXQgdG91Y2hQb2ludCA9IGV2ZW50LmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgICAgIGxldCBlbmRYID0gdGhpcy5maXJzdFggLSB0b3VjaFBvaW50Lng7XHJcbiAgICAgICAgICAgIGxldCBlbmRZID0gdGhpcy5maXJzdFkgLSB0b3VjaFBvaW50Lnk7XHJcblxyXG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMoZW5kWCkgPiBNYXRoLmFicyhlbmRZKSkge1xyXG4gICAgICAgICAgICAgICAgLy/miYvlir/lkJHlt6blj7NcclxuICAgICAgICAgICAgICAgIC8v5Yik5pat5ZCR5bem6L+Y5piv5ZCR5Y+zIFxyXG4gICAgICAgICAgICAgICAgaWYgKGVuZFggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/lkJHlt6blh73mlbBcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coJ2xlZnQnKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/lkJHlj7Plh73mlbBcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coJ3JpZ2h0Jyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL+aJi+WKv+WQkeS4iuS4i1xyXG4gICAgICAgICAgICAgICAgLy/liKTmlq3miYvlir/lkJHkuIrov5jmmK/lkJHkuItcclxuICAgICAgICAgICAgICAgIGlmIChlbmRZID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5ZCR5LiL5Ye95pWwXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKCdkb3duJyk7XHJcblxyXG5cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/lkJHkuIrlh73mlbBcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coJ3VwJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MudHdlZW4oZXZlbnROb2RlLnBhcmVudClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvKDMsIHsgeTogMTAwMDAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wYWdlSW5kZXggKz0gMTtcclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5wYWdlSW5kZXggPiAxICYmIHRoaXMucGFnZUluZGV4IDwgNikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnF1ZXN0aW9uTm9kZVt0aGlzLnBhZ2VJbmRleCAtIDFdLmdldENoaWxkQnlOYW1lKFwicXVlc3Rpb25cIikuZ2V0Q2hpbGRCeU5hbWUoXCJsYXlvdXRcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAuZGVsYXkoMC43KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvKDEsIHsgeDogLTEgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5wYWdlSW5kZXggPT09IDIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5xdWVzdGlvbk5vZGVbdGhpcy5wYWdlSW5kZXggLSAxXS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKS5nZXRDaGlsZEJ5TmFtZShcImJ1dHRlcmZseVwiKS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKS5wbGF5KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucGFnZUluZGV4ID09PSAzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlW3RoaXMucGFnZUluZGV4IC0gMV0uZ2V0Q2hpbGRCeU5hbWUoXCJxdWVzdGlvblwiKS5nZXRDaGlsZEJ5TmFtZShcInRhblFpXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvKDEuMywgeyBzY2FsZTogMSB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlW3RoaXMucGFnZUluZGV4IC0gMV0uZ2V0Q2hpbGRCeU5hbWUoXCJxdWVzdGlvblwiKS5nZXRDaGlsZEJ5TmFtZShcInRhbGtcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG8oMSwgeyBzY2FsZTogMSB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnBhZ2VJbmRleCA9PT0gNCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnF1ZXN0aW9uTm9kZVt0aGlzLnBhZ2VJbmRleCAtIDFdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpLmdldENoaWxkQnlOYW1lKFwidGhyZWViYWxsb29uXCIpLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pLnBsYXkoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5xdWVzdGlvbk5vZGVbdGhpcy5wYWdlSW5kZXggLSAxXS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKS5nZXRDaGlsZEJ5TmFtZShcIndhdGVyIHBsYW5ldCBiYWxsb25cIikuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnF1ZXN0aW9uTm9kZVt0aGlzLnBhZ2VJbmRleCAtIDFdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpLmdldENoaWxkQnlOYW1lKFwiMWJhbGxvb25cIikuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnF1ZXN0aW9uTm9kZVt0aGlzLnBhZ2VJbmRleCAtIDFdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpLmdldENoaWxkQnlOYW1lKFwiMmJhbGxvb25cIikuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucGFnZUluZGV4ID09PSA2KSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnByb2R1Y3QuZ2V0Q2hpbGRCeU5hbWUoXCJzdGFyXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvKDAuNywgeyBvcGFjaXR5OiAyNTUgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYWxsKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2R1Y3QuZ2V0Q2hpbGRCeU5hbWUoXCJpbnRyb2R1Y3Rpb25cIikuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIHRoaXMpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBxdWVzdGlvblNlbGVjdChldmVudDogYW55LCB2YWx1ZTogc3RyaW5nKTogdm9pZCB7XHJcblxyXG4gICAgICAgIHRoaXMuY2xpY2tBdWRpby5wbGF5KCk7XHJcblxyXG4gICAgICAgIHN3aXRjaCAodmFsdWUpIHtcclxuICAgICAgICAgICAgY2FzZSBcInN0YXJ0XCI6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmt2LmdldENoaWxkQnlOYW1lKFwiYmlnU3RhclwiKS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKS5zdG9wKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmt2LmdldENoaWxkQnlOYW1lKFwic3RhclwiKS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKS5zdG9wKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmt2LmdldENoaWxkQnlOYW1lKFwiYmlnU3RhclwiKS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMua3YuZ2V0Q2hpbGRCeU5hbWUoXCJzdGFyXCIpLmFjdGl2ZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMua3YpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDMsIHsgeTogMTAwMDAgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3RhcnQoKVxyXG5cclxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlWzBdLmdldENoaWxkQnlOYW1lKFwicXVlc3Rpb25cIikuZ2V0Q2hpbGRCeU5hbWUoXCJsYXlvdXRcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgLmRlbGF5KDAuNylcclxuICAgICAgICAgICAgICAgICAgICAudG8oMSwgeyB4OiAtMSB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcblxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCIxXCI6XHJcbiAgICAgICAgICAgIGNhc2UgXCIyXCI6XHJcbiAgICAgICAgICAgIGNhc2UgXCIzXCI6XHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnF1ZXN0aW9uTm9kZVswXS5nZXRDaGlsZEJ5TmFtZShcInF1ZXN0aW9uXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgIC50byg0LCB7IHk6IDEwMDAwIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnF1ZXN0aW9uTm9kZVswXS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlcjFcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDEsIHsgb3BhY2l0eTogMjU1IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnF1ZXN0aW9uTm9kZVswXS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlcjJcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgLmRlbGF5KDEpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDEsIHsgb3BhY2l0eTogMjU1IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvdWNoQ2hlY2sodGhpcy5xdWVzdGlvbk5vZGVbMF0uZ2V0Q2hpbGRCeU5hbWUoXCJhbnN3ZXJcIikpO1xyXG5cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwiNFwiOlxyXG4gICAgICAgICAgICBjYXNlIFwiNVwiOlxyXG4gICAgICAgICAgICBjYXNlIFwiNlwiOlxyXG4gICAgICAgICAgICAgICAgY2MudHdlZW4odGhpcy5xdWVzdGlvbk5vZGVbMV0uZ2V0Q2hpbGRCeU5hbWUoXCJxdWVzdGlvblwiKSlcclxuICAgICAgICAgICAgICAgICAgICAudG8oNCwgeyB5OiAxMDAwMCB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcblxyXG4gICAgICAgICAgICAgICAgY2MudHdlZW4odGhpcy5xdWVzdGlvbk5vZGVbMV0uZ2V0Q2hpbGRCeU5hbWUoXCJhbnN3ZXJcIikuZ2V0Q2hpbGRCeU5hbWUoXCJhbnN3ZXIxXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgIC50bygxLCB7IG9wYWNpdHk6IDI1NSB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcblxyXG4gICAgICAgICAgICAgICAgY2MudHdlZW4odGhpcy5xdWVzdGlvbk5vZGVbMV0uZ2V0Q2hpbGRCeU5hbWUoXCJhbnN3ZXJcIikuZ2V0Q2hpbGRCeU5hbWUoXCJhbnN3ZXIyXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5kZWxheSgxKVxyXG4gICAgICAgICAgICAgICAgICAgIC50bygxLCB7IG9wYWNpdHk6IDI1NSB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy50b3VjaENoZWNrKHRoaXMucXVlc3Rpb25Ob2RlWzFdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpKTtcclxuXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCI3XCI6XHJcbiAgICAgICAgICAgIGNhc2UgXCI4XCI6XHJcbiAgICAgICAgICAgIGNhc2UgXCI5XCI6XHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnF1ZXN0aW9uTm9kZVsyXS5nZXRDaGlsZEJ5TmFtZShcInF1ZXN0aW9uXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgIC50byg0LCB7IHk6IDEwMDAwIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnF1ZXN0aW9uTm9kZVsyXS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlcjFcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDEsIHsgb3BhY2l0eTogMjU1IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnF1ZXN0aW9uTm9kZVsyXS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlcjJcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgLmRlbGF5KDEpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDEsIHsgb3BhY2l0eTogMjU1IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvdWNoQ2hlY2sodGhpcy5xdWVzdGlvbk5vZGVbMl0uZ2V0Q2hpbGRCeU5hbWUoXCJhbnN3ZXJcIikpO1xyXG5cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcIjEwXCI6XHJcbiAgICAgICAgICAgIGNhc2UgXCIxMVwiOlxyXG4gICAgICAgICAgICBjYXNlIFwiMTJcIjpcclxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlWzNdLmdldENoaWxkQnlOYW1lKFwicXVlc3Rpb25cIikpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDQsIHsgeTogMTAwMDAgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3RhcnQoKVxyXG5cclxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlWzNdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyMVwiKSlcclxuICAgICAgICAgICAgICAgICAgICAudG8oMSwgeyBvcGFjaXR5OiAyNTUgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3RhcnQoKVxyXG5cclxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlWzNdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyMlwiKSlcclxuICAgICAgICAgICAgICAgICAgICAuZGVsYXkoMSlcclxuICAgICAgICAgICAgICAgICAgICAudG8oMSwgeyBvcGFjaXR5OiAyNTUgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3RhcnQoKVxyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMudG91Y2hDaGVjayh0aGlzLnF1ZXN0aW9uTm9kZVszXS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiMTNcIjpcclxuICAgICAgICAgICAgY2FzZSBcIjE0XCI6XHJcbiAgICAgICAgICAgIGNhc2UgXCIxNVwiOlxyXG4gICAgICAgICAgICAgICAgY2MudHdlZW4odGhpcy5xdWVzdGlvbk5vZGVbNF0uZ2V0Q2hpbGRCeU5hbWUoXCJxdWVzdGlvblwiKSlcclxuICAgICAgICAgICAgICAgICAgICAudG8oNCwgeyB5OiAxMDAwMCB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcblxyXG5cclxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlWzRdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyMVwiKSlcclxuICAgICAgICAgICAgICAgICAgICAudG8oMSwgeyBvcGFjaXR5OiAyNTUgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3RhcnQoKVxyXG5cclxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucXVlc3Rpb25Ob2RlWzRdLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyXCIpLmdldENoaWxkQnlOYW1lKFwiYW5zd2VyMlwiKSlcclxuICAgICAgICAgICAgICAgICAgICAuZGVsYXkoMSlcclxuICAgICAgICAgICAgICAgICAgICAudG8oMSwgeyBvcGFjaXR5OiAyNTUgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3RhcnQoKVxyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMudG91Y2hDaGVjayh0aGlzLnF1ZXN0aW9uTm9kZVs0XS5nZXRDaGlsZEJ5TmFtZShcImFuc3dlclwiKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJsb29rXCI6XHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnByb2R1Y3QpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDQsIHsgeTogMTAwMDAgfSlcclxuICAgICAgICAgICAgICAgICAgICAuY2FsbCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5pdFJlbmRlcigpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnBvc3RlcnMuZ2V0Q2hpbGRCeU5hbWUoXCJjYXRcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgLnJlcGVhdEZvcmV2ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLnR3ZWVuKHRoaXMucG9zdGVycy5nZXRDaGlsZEJ5TmFtZShcImNhdFwiKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50bygwLjYsIHsgeTogNDMwIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG8oMC42LCB7IHk6IDQyMCB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuICAgICAgICAgICAgICAgICAgICApLnN0YXJ0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgY2MudHdlZW4odGhpcy5wb3N0ZXJzLmdldENoaWxkQnlOYW1lKFwic3RhclwiKSlcclxuICAgICAgICAgICAgICAgICAgICAudG8oMC44LCB7IG9wYWNpdHk6IDI1NSB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdGFydCgpXHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IHJhbmQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0KTtcclxuXHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLnBvc3RlcnMuZ2V0Q2hpbGRCeU5hbWUoXCJzdGFyXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgIC50bygwLjgsIHsgb3BhY2l0eTogMjU1IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KClcclxuXHJcbiAgICAgICAgICAgICAgICBjYy50d2Vlbih0aGlzLmNvcHl3cml0aW5nW3JhbmRdKVxyXG4gICAgICAgICAgICAgICAgICAgIC5kZWxheSgwLjgpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvKDAuOCwgeyBvcGFjaXR5OiAyNTUgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3RhcnQoKVxyXG5cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwiYWdhaW5cIjpcclxuICAgICAgICAgICAgICAgIGhpc3RvcnkuZ28oMCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcInNoYXJlXCI6XHJcblxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJjbG9zZVNoYXJlXCI6XHJcbiAgICAgICAgICAgICAgICBsZXQgZGl2X2J0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGl2X2J0blwiKVxyXG4gICAgICAgICAgICAgICAgZGl2X2J0bi5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xyXG4gICAgICAgICAgICAgICAgbGV0IG11c2ljMiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYXVkaW9fYm94SURcIilcclxuICAgICAgICAgICAgICAgIG11c2ljMi5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuc2hhcmVOb2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwidGFvXCI6XHJcblxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBjb3B5VG9DbGlwQm9hcmQoKSB7XHJcbiAgICAgICAgaWYgKGNjLnN5cy5pc05hdGl2ZSkge1xyXG4gICAgICAgICAgICAvL+WOn+eUn+iHquW3seWunueOsFxyXG4gICAgICAgIH0gZWxzZSBpZiAoY2Muc3lzLmlzQnJvd3Nlcikge1xyXG4gICAgICAgICAgICB2YXIgdGV4dEFyZWEgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNsaXBCb2FyZFwiKTtcclxuICAgICAgICAgICAgaWYgKHRleHRBcmVhID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICB0ZXh0QXJlYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJ0ZXh0YXJlYVwiKTtcclxuICAgICAgICAgICAgICAgIHRleHRBcmVhLmlkID0gXCJjbGlwQm9hcmRcIjtcclxuICAgICAgICAgICAgICAgIHRleHRBcmVhLnRleHRDb250ZW50ID0gXCLvv6UxWlFYY3liMlBIYu+/pVwiO1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0ZXh0QXJlYSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGV4dEFyZWEuc2VsZWN0KCk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBtc2cgPSBkb2N1bWVudC5leGVjQ29tbWFuZCgnY29weScpID8gJ3N1Y2Nlc3NmdWwnIDogJ3Vuc3VjY2Vzc2Z1bCc7XHJcbiAgICAgICAgICAgICAgICBjYy5sb2coXCLlt7Lnu4/lpI3liLbliLDliarotLTmnb9cIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvYXN0LmdldENoaWxkQnlOYW1lKFwiaW5mb1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwi5bey57uP5aSN5Yi25Yiw5Ymq6LS05p2/XCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvYXN0LmFjdGl2ZSA9IHRydWVcclxuICAgICAgICAgICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodGV4dEFyZWEpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudG9hc3QuZ2V0Q2hpbGRCeU5hbWUoXCJpbmZvXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gXCLlpI3liLbliLDliarotLTmnb/lpLHotKVcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMudG9hc3QuYWN0aXZlID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5aSN5Yi25Yiw5Ymq6LS05p2/5aSx6LSlXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMudG9hc3QuZ2V0Q2hpbGRCeU5hbWUoXCJpbmZvXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc2NoZWR1bGVPbmNlKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMudG9hc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH0sIDIpO1xyXG5cclxuXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwcml2YXRlIGluaXRSZW5kZXIoKSB7XHJcbiAgICAgICAgLy8gaWYoY2Muc3lzLmlzQnJvd3NlcilcclxuICAgICAgICAvLyB7XHJcbiAgICAgICAgbGV0IG5vZGUgPSBuZXcgY2MuTm9kZSgpO1xyXG4gICAgICAgIG5vZGUucGFyZW50ID0gY2MuZGlyZWN0b3IuZ2V0U2NlbmUoKS5nZXRDaGlsZEJ5TmFtZShcIkNhbnZhc1wiKTtcclxuICAgICAgICBsZXQgY2FtZXJhID0gbm9kZS5hZGRDb21wb25lbnQoY2MuQ2FtZXJhKTtcclxuICAgICAgICAvL+iuvue9ruebuOacuuWPguaVsFxyXG5cclxuICAgICAgICBjYW1lcmEuZW5hYmxlZCA9IGZhbHNlOyAvLyDpgb/lhY3oh6rliqjmuLLmn5NcclxuICAgICAgICAvLyDmiKrlm77nmoTnvKnmlL7mr5TkvotcclxuICAgICAgICBsZXQgem9vbSA9IDE7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gY2Mud2luU2l6ZS53aWR0aDtcclxuICAgICAgICBsZXQgaGVpZ2h0ID1cclxuICAgICAgICAgICAgKGNjLndpblNpemUud2lkdGggKiBjYy52aWV3LmdldEZyYW1lU2l6ZSgpLmhlaWdodCkgL1xyXG4gICAgICAgICAgICBjYy52aWV3LmdldEZyYW1lU2l6ZSgpLndpZHRoO1xyXG4gICAgICAgIGxldCBzaXplID0gY2Muc2l6ZSh3aWR0aCwgaGVpZ2h0KTtcclxuICAgICAgICAvLyDmiKrlm77nmoTkuK3lv4PngrnlsLHmmK/mkYTlg4/mnLroioLngrnnmoTkvY3nva5cclxuICAgICAgICBsZXQgb3JpZ2luID0gY2MudjIoMCwgMCk7XHJcblxyXG4gICAgICAgIGNhbWVyYS56b29tUmF0aW8gPSB6b29tOyAvLyDorr7nva7nvKnmlL5cclxuXHJcbiAgICAgICAgLy8g6K6+572u55uu5qCH5riy5p+T57q555CGXHJcbiAgICAgICAgbGV0IHRleHR1cmUgPSBuZXcgY2MuUmVuZGVyVGV4dHVyZSgpO1xyXG4gICAgICAgIGxldCBnbCA9IGNjLmdhbWVbXCJfcmVuZGVyQ29udGV4dFwiXTtcclxuXHJcbiAgICAgICAgdGV4dHVyZS5pbml0V2l0aFNpemUoc2l6ZS53aWR0aCwgc2l6ZS5oZWlnaHQsIGdsLlNURU5DSUxfSU5ERVg4KTsgLy8g5oiq5Zu+55+p5b2i55qE5bC65a+4XHJcbiAgICAgICAgLy90aGlzLm5vZGUuc2V0UG9zaXRpb24ob3JpZ2luKTsgICAgICAgICAgICAgICAgICAvLyDmiKrlm77nn6nlvaLnmoTkuK3lv4PngrlcclxuICAgICAgICBjYW1lcmEudGFyZ2V0VGV4dHVyZSA9IHRleHR1cmU7XHJcblxyXG4gICAgICAgIC8vIOe8k+WtmO+8jOWkh+eUqFxyXG4gICAgICAgIHRoaXMuX2NhbWVyYSA9IGNhbWVyYTtcclxuICAgICAgICB0aGlzLl90ZXh0dXJlID0gdGV4dHVyZTtcclxuXHJcbiAgICAgICAgLy/nlKjkuo7mmL7npLrnmoRzcHJpdGXnu4Tku7bvvIzlpoLmnpzopoHmtYvor5Xov5nkuKrvvIzpnIDopoHmt7vliqBzcHJpdGXnu4Tku7ZcclxuICAgICAgICAvL3RoaXMuX3Nwcml0ZSA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgdGhpcy5idG5faW1hZ2Vfa25pZmUoKTtcclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQGRlc2NyaXB0aW9uOiDlvIDlp4vmiKrlm75cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBidG5faW1hZ2Vfa25pZmUoKSB7XHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICB0aGlzLnBvc3RlcnMuZ2V0Q2hpbGRCeU5hbWUoXCJ0YW9cIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5wb3N0ZXJzLmdldENoaWxkQnlOYW1lKFwiYWdhaW5cIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5wb3N0ZXJzLmdldENoaWxkQnlOYW1lKFwic2hhcmVcIikuYWN0aXZlID0gZmFsc2U7XHJcblxyXG4gICAgICAgIC8vIOaJp+ihjOS4gOasoSByZW5kZXLvvIzlsIbmiYDmuLLmn5PnmoTlhoXlrrnmuLLmn5PliLDnurnnkIbkuIpcclxuICAgICAgICB0aGlzLl9jYW1lcmEucmVuZGVyKHVuZGVmaW5lZCk7XHJcbiAgICAgICAgLy/liLDov5nph4zvvIzmiKrlm77lsLHlt7Lnu4/lrozmiJDkuoZcclxuXHJcblxyXG4gICAgICAgIHRoaXMucG9zdGVycy5nZXRDaGlsZEJ5TmFtZShcInRhb1wiKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMucG9zdGVycy5nZXRDaGlsZEJ5TmFtZShcImFnYWluXCIpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5wb3N0ZXJzLmdldENoaWxkQnlOYW1lKFwic2hhcmVcIikuYWN0aXZlID0gdHJ1ZTtcclxuXHJcblxyXG4gICAgICAgIC8vIOaOpeS4i+WOu++8jOWPr+S7peS7jiBSZW5kZXJUZXh0dXJlIOS4reiOt+WPluaVsOaNru+8jOi/m+ihjOa3seWKoOW3pVxyXG4gICAgICAgIGxldCB0ZXh0dXJlID0gdGhpcy5fdGV4dHVyZTtcclxuICAgICAgICBsZXQgZGF0YSA9IHRleHR1cmUucmVhZFBpeGVscygpO1xyXG5cclxuICAgICAgICBsZXQgd2lkdGggPSB0ZXh0dXJlLndpZHRoOyBgYFxyXG4gICAgICAgIGxldCBoZWlnaHQgPSB0ZXh0dXJlLmhlaWdodDtcclxuXHJcbiAgICAgICAgLy8g5o6l5LiL5p2l5bCx5Y+v5Lul5a+56L+Z5Lqb5pWw5o2u6L+b6KGM5pON5L2c5LqGXHJcbiAgICAgICAgLy8gbGV0IGNhbnZhczpIVE1MQ2FudmFzRWxlbWVudDtcclxuICAgICAgICBsZXQgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcclxuICAgICAgICAvLyBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGJ0bik7IC8vIOayoeaciea3u+WKoOWIsGJvZHnkuIrvvIzkuI3nlKjmi4Xlv4PlhoXlrZjms4TmvI9cclxuXHJcbiAgICAgICAgbGV0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XHJcbiAgICAgICAgY2FudmFzLndpZHRoID0gd2lkdGg7XHJcbiAgICAgICAgY2FudmFzLmhlaWdodCA9IGhlaWdodDtcclxuXHJcbiAgICAgICAgLy8gMee7tOaVsOe7hOi9rDLnu7RcclxuICAgICAgICAvLyDlkIzml7blgZrkuKrkuIrkuIvnv7vovaxcclxuICAgICAgICBsZXQgcm93Qnl0ZXMgPSB3aWR0aCAqIDQ7XHJcbiAgICAgICAgZm9yIChsZXQgcm93ID0gMDsgcm93IDwgaGVpZ2h0OyByb3crKykge1xyXG4gICAgICAgICAgICBsZXQgc3JvdyA9IGhlaWdodCAtIDEgLSByb3c7XHJcbiAgICAgICAgICAgIGxldCBpbWFnZURhdGEgPSBjdHguY3JlYXRlSW1hZ2VEYXRhKHdpZHRoLCAxKTtcclxuICAgICAgICAgICAgbGV0IHN0YXJ0ID0gc3JvdyAqIHdpZHRoICogNDtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByb3dCeXRlczsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpbWFnZURhdGEuZGF0YVtpXSA9IGRhdGFbc3RhcnQgKyBpXTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY3R4LnB1dEltYWdlRGF0YShpbWFnZURhdGEsIDAsIHJvdyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBkYXRhVXJsID0gY2FudmFzLnRvRGF0YVVSTChcImltYWdlL2pwZWdcIik7XHJcbiAgICAgICAgbGV0IGltZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIik7XHJcbiAgICAgICAgaW1nLnNyYyA9IGRhdGFVcmw7IC8v5oiq5Zu+5pWw5o2uXHJcbiAgICAgICAgaW1nLmlkID0gXCJjYXB0dXJlXCI7XHJcbiAgICAgICAgaW1nLmFsdCA9IFwiY2FwdHVyZVwiO1xyXG4gICAgICAgIGltZy53aWR0aCA9IHdpZHRoO1xyXG4gICAgICAgIGltZy5oZWlnaHQgPSBoZWlnaHQ7XHJcbiAgICAgICAgaW1nLnN0eWxlLnBvc2l0aW9uID0gXCJmaXhlZFwiO1xyXG4gICAgICAgIGltZy5zdHlsZS50b3AgPSBcIjUwJVwiO1xyXG4gICAgICAgIGltZy5zdHlsZS5sZWZ0ID0gXCI1MCVcIjtcclxuICAgICAgICBpbWcuc3R5bGUub3BhY2l0eSA9IFwiMFwiO1xyXG4gICAgICAgIGltZy5zdHlsZS50cmFuc2Zvcm0gPSBcInRyYW5zbGF0ZSgtNTAlLC01MCUpXCI7XHJcbiAgICAgICAgLy8gaW1nLm9uY2xpY2sgPSBmdW5jdGlvbiBmdW5fY2FsbCgpIHtcclxuICAgICAgICAvLyAgICAgaWYgKHNlbGYuc2hhcmVMYXlvdXQuYWN0aXZlID09IHRydWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIC8vIHNlbGYubm9kZV9zaGFyZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAvLyAgICAgICAgIHNlbGYuc2hhcmVMYXlvdXQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9O1xyXG5cclxuXHJcbiAgICAgICAgLy/liJvlu7rmjInpkq5kaXZcclxuICAgICAgICBsZXQgZGl2X2J0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XHJcbiAgICAgICAgZGl2X2J0bi5pZCA9IFwiZGl2X2J0blwiO1xyXG4gICAgICAgIGRpdl9idG4uc3R5bGUucG9zaXRpb24gPSBcImZpeGVkXCI7XHJcbiAgICAgICAgZGl2X2J0bi5zdHlsZS50b3AgPSBcIjUwJVwiO1xyXG4gICAgICAgIGRpdl9idG4uc3R5bGUubGVmdCA9IFwiMHB4XCI7XHJcbiAgICAgICAgZGl2X2J0bi5zdHlsZS53aWR0aCA9IFwiMTAwJVwiO1xyXG4gICAgICAgIGRpdl9idG4uc3R5bGUuaGVpZ2h0ID0gXCI1ODRweFwiO1xyXG5cclxuICAgICAgICBkaXZfYnRuLmFwcGVuZENoaWxkKGltZyk7XHJcblxyXG4gICAgICAgIC8v5Yqg5oyJ6ZKuXHJcbiAgICAgICAgbGV0IGJ0bl9hZ2FpbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XHJcbiAgICAgICAgYnRuX2FnYWluLmlkID0gXCJidG5fYWdhaW5cIjtcclxuICAgICAgICBidG5fYWdhaW4uc3R5bGUud2lkdGggPSBcIjE1MHB4XCI7XHJcbiAgICAgICAgYnRuX2FnYWluLnN0eWxlLmhlaWdodCA9IFwiNjBweFwiO1xyXG4gICAgICAgIGJ0bl9hZ2Fpbi5zdHlsZS5wb3NpdGlvbiA9IFwiYWJzb2x1dGVcIjtcclxuICAgICAgICBidG5fYWdhaW4uc3R5bGUuYm90dG9tID0gXCIzMDBweFwiO1xyXG4gICAgICAgIGJ0bl9hZ2Fpbi5zdHlsZS5sZWZ0ID0gXCIyM3B4XCI7XHJcbiAgICAgICAgYnRuX2FnYWluLnN0eWxlLnJpZ2h0ID0gXCIwcHhcIjtcclxuICAgICAgICAvLyBidG5fYWdhaW4uc3R5bGUubWFyZ2luID0gXCJhdXRvXCI7XHJcblxyXG4gICAgICAgIGRpdl9idG4uYXBwZW5kQ2hpbGQoYnRuX2FnYWluKTtcclxuICAgICAgICAvL+WGjeasoea4uOaIj1xyXG4gICAgICAgIGJ0bl9hZ2Fpbi5vbmNsaWNrID0gZnVuY3Rpb24gZnVuY19hZ2FpbigpIHtcclxuICAgICAgICAgICAgaGlzdG9yeS5nbygwKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICAvL+WKoOaMiemSrlxyXG4gICAgICAgIGxldCBidG5fc2hhcmUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICAgIGJ0bl9zaGFyZS5pZCA9IFwiYnRuX3NoYXJlXCI7XHJcbiAgICAgICAgYnRuX3NoYXJlLnN0eWxlLndpZHRoID0gXCIxNTBweFwiO1xyXG4gICAgICAgIGJ0bl9zaGFyZS5zdHlsZS5oZWlnaHQgPSBcIjYwcHhcIjtcclxuICAgICAgICBidG5fc2hhcmUuc3R5bGUucG9zaXRpb24gPSBcImFic29sdXRlXCI7XHJcbiAgICAgICAgYnRuX3NoYXJlLnN0eWxlLmJvdHRvbSA9IFwiMzAwcHhcIjtcclxuICAgICAgICAvLyBidG5fc2hhcmUuc3R5bGUubGVmdCA9IFwiMHB4XCI7XHJcbiAgICAgICAgYnRuX3NoYXJlLnN0eWxlLnJpZ2h0ID0gXCIzMHB4XCI7XHJcbiAgICAgICAgLy8gYnRuX2FnYWluLnN0eWxlLm1hcmdpbiA9IFwiYXV0b1wiO1xyXG5cclxuICAgICAgICBkaXZfYnRuLmFwcGVuZENoaWxkKGJ0bl9zaGFyZSk7XHJcbiAgICAgICAgLy/lho3mrKHmuLjmiI9cclxuICAgICAgICBidG5fc2hhcmUub25jbGljayA9IGZ1bmN0aW9uIGZ1bmNfYWdhaW4oKSB7XHJcbiAgICAgICAgICAgIHNlbGYuc2hhcmVOb2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIGxldCBtdXNpYyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYXVkaW9fYm94SURcIilcclxuICAgICAgICAgICAgZGl2X2J0bi5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICAgICAgICAgIG11c2ljLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcclxuICAgICAgICB9O1xyXG5cclxuXHJcblxyXG4gICAgICAgIC8v5Yqg5oyJ6ZKuXHJcbiAgICAgICAgbGV0IGJ0bl90YW8gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICAgIGJ0bl90YW8uaWQgPSBcImJ0bl90YW9cIjtcclxuICAgICAgICBidG5fdGFvLnN0eWxlLndpZHRoID0gXCIxNjBweFwiO1xyXG4gICAgICAgIGJ0bl90YW8uc3R5bGUuaGVpZ2h0ID0gXCI1MHB4XCI7XHJcbiAgICAgICAgYnRuX3Rhby5zdHlsZS5wb3NpdGlvbiA9IFwiYWJzb2x1dGVcIjtcclxuICAgICAgICBidG5fdGFvLnN0eWxlLmJvdHRvbSA9IFwiMzcwcHhcIjtcclxuICAgICAgICBidG5fdGFvLnN0eWxlLmxlZnQgPSBcIjBweFwiO1xyXG4gICAgICAgIGJ0bl90YW8uc3R5bGUucmlnaHQgPSBcIjBweFwiO1xyXG4gICAgICAgIGJ0bl90YW8uc3R5bGUubWFyZ2luID0gXCJhdXRvXCI7XHJcblxyXG4gICAgICAgIGRpdl9idG4uYXBwZW5kQ2hpbGQoYnRuX3Rhbyk7XHJcbiAgICAgICAgLy/lho3mrKHmuLjmiI9cclxuICAgICAgICBidG5fdGFvLm9uY2xpY2sgPSBmdW5jdGlvbiBmdW5jX2FnYWluKCkge1xyXG4gICAgICAgICAgICBzZWxmLmNvcHlUb0NsaXBCb2FyZCgpO1xyXG4gICAgICAgIH07XHJcblxyXG5cclxuXHJcblxyXG4gICAgICAgIGxldCBkaXZHYW1lID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJDb2NvczJkR2FtZUNvbnRhaW5lclwiKTtcclxuICAgICAgICBkaXZHYW1lLmFwcGVuZENoaWxkKGRpdl9idG4pO1xyXG4gICAgICAgIC8vIGNyZWF0ZUVyd2VpbWEoKTtcclxuXHJcbiAgICAgICAgLy/miKrlm77lrozmiJDlkI7pmpDol49cclxuICAgICAgICAvLyB0aGlzLm5vZGVfc2F2ZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAvL+aIquWbvuWujOaIkOWQjuaYvuekuue7k+aenOmhtVxyXG4gICAgICAgIC8vIHRoaXMubm9kZV9yZXN1bHQuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAvLyB0aGlzLm5vZGVfcmVzdWx0X3dpbi5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIC8vIHRoaXMubm9kZV9yZXN1bHQuZ2V0Q2hpbGRCeU5hbWUoXCJyZXN1bHRfXCIgKyB0aGlzLnF1ZXN0aW9uX2luZGV4KS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------
