"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GameState_1 = require("./GameState");
const gameServer = {
    mode: 'async',
    onInitGameData: function () {
        return {
            syncType: GameState_1.SyncType.msg,
            timer: undefined,
            players: [],
        };
    },
    onRecvFromClient: function ({ actionData, sender, gameData, SDK, room, exports }) {
        const cmd = actionData.cmd;
        GameState_1.setPlayer(sender, cmd, gameData);
    },
    onJoinRoom: function ({ actionData, gameData, SDK, room, exports }) {
        GameState_1.initPlayer(actionData.joinPlayerId, gameData, 0, room.playerList.findIndex(p => p.id === actionData.joinPlayerId));
    },
    onLeaveRoom: function ({ actionData, gameData, SDK, room, exports }) {
        if (!room || !room.playerList || room.playerList.length === 0) {
            // 房间无人
            return GameState_1.clearGameState(gameData);
        }
        GameState_1.removePlayer(actionData.leavePlayerId, gameData);
    },
    onDestroyRoom: function ({ actionData, gameData, SDK, room, exports }) {
        GameState_1.clearGameState(gameData);
    },
    onChangeRoom: function (args) {
        if (args.gameData.timer && args.room && args.room.customProperties === GameState_1.SyncType.state) {
            return;
        }
        if (!args.room || args.room.customProperties !== GameState_1.SyncType.state) {
            GameState_1.clearGameState(args.gameData);
        }
        if (args.room && args.room.customProperties === GameState_1.SyncType.state) {
            GameState_1.initGameState(args.gameData, args);
        }
    },
};
// 服务器初始化时调用
function onInitGameServer(tcb) {
    // 如需要，可以在此初始化 TCB
    const tcbApp = tcb.init({
        secretId: "请填写腾讯云API密钥ID",
        secretKey: "请填写腾讯云API密钥KEY",
        env: "请填写云开发环境ID",
        serviceUrl: 'http://tcb-admin.tencentyun.com/admin',
        timeout: 5000,
    });
    // ...
}
exports.mgobexsCode = {
    logLevel: 'error+',
    logLevelSDK: 'error+',
    gameInfo: {
        gameId: "请填写游戏ID",
        serverKey: "请填写后端密钥",
    },
    onInitGameServer,
    gameServer
};
